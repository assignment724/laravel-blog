<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
    <path d="M40 50 L160 50 L160 150 L40 150 C30 150 25 145 25 140 L25 60 C25 55 30 50 40 50" fill="#4338ca"/>
    
    <path d="M40 55 L155 55 L155 145 L40 145" fill="white" stroke="#e5e7eb"/>
    
    <line x1="50" y1="75" x2="145" y2="75" stroke="#6366f1" stroke-width="3"/>
    <line x1="50" y1="95" x2="145" y2="95" stroke="#6366f1" stroke-width="3"/>
    <line x1="50" y1="115" x2="120" y2="115" stroke="#6366f1" stroke-width="3"/>
    
    <path d="M60 30 L140 30 L100 10 Z" fill="#312e81"/>
    <rect x="95" y="30" width="10" height="15" fill="#312e81"/>
    
    <path d="M105 45 Q110 50 115 45" stroke="#312e81" stroke-width="2" fill="none"/>
</svg>